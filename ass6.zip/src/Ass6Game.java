/**.
 * @author Tzahi elhadad
 * ID 206214165
 */
import animation.AnimationRunner;
import biuoop.KeyboardSensor;
import game.GameFlow;
import levels.DirectHit;
import levels.Green3;
import levels.LevelInformation;
import levels.WideEasy;
import levels.FinalFour;
import java.util.ArrayList;
import java.util.List;

/**.
 * Main class for assigment 6.
 */
public class Ass6Game {
    /**.
     * Main function for ASS6, starting the game.
     * @param args - not get arguments from the user.
     */
    public static void main(String[] args) {
        // make animation runner and keyboard sensor for the game.
        AnimationRunner animationRunner = new AnimationRunner();
        KeyboardSensor keyboard = animationRunner.getKeyboard();
        // make 4 levels of game.
        LevelInformation level1 = new DirectHit();
        LevelInformation level2 = new WideEasy();
        LevelInformation level3 = new Green3();
        LevelInformation level4 = new FinalFour();
        // make list of LevelInformation
        List<LevelInformation> listLevels = new ArrayList<LevelInformation>();
        // make a gameFlow with 7 lives.
        GameFlow game = new GameFlow(animationRunner, keyboard, 7);
        // if we d'ont get arguments from the user, play 4 levels.
        if (args.length != 0) {
            for (String s : args) {
                // if pressed 1 for level 1.
                if (s.equals("1")) {
                    listLevels.add(level1);
                } else if (s.equals("2")) { // if pressed 2 for level 2.
                    listLevels.add(level2);
                } else if (s.equals("3")) { // if pressed 3 for level 3.
                    listLevels.add(level3);
                } else if (s.equals("4")) { // if pressed 4 for level 4.
                    listLevels.add(level4);
                }
            }
        }
        // if listLevels is empty
            if (listLevels.isEmpty()) {
                listLevels.add(level1);
                listLevels.add(level2);
                listLevels.add(level3);
                listLevels.add(level4);
                game.runLevels(listLevels);
            } else { // we get arguments from user.
                game.runLevels(listLevels);
        }
    }
}
